﻿namespace UnityVolumeRendering
{
    public enum DensitySource
    {
        Unknown,
        Alpha,
        Grey
    }
}